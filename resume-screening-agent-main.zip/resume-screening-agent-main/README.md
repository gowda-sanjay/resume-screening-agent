# 🤖 AI Resume Screening Agent

> An intelligent Resume Screening Agent built for the **Rooman Technologies 24-Hour AI Agent Challenge**. The application automatically analyzes resumes against a job description using NLP and semantic similarity, ranks candidates, and generates downloadable reports for recruiters.

---

## 📌 Project Overview

Recruiters often spend hours manually reviewing resumes. This AI-powered Resume Screening Agent automates the initial screening process by:

- Parsing resumes (PDF, DOCX, TXT)
- Extracting candidate information
- Comparing resumes with a Job Description (JD)
- Calculating semantic similarity using AI
- Ranking candidates based on weighted criteria
- Exporting ranked results as CSV and JSON

The system provides recruiters with a fast, transparent, and explainable way to identify the most suitable candidates.

---

## ✨ Key Features

- 📄 Upload a Job Description (PDF/TXT)
- 📂 Upload Multiple Candidate Resumes
- 🧠 AI-powered Resume Parsing
- 🔍 Semantic Similarity Matching
- 📊 Weighted Candidate Scoring
- 🏆 Automatic Candidate Ranking
- 📁 Export Results (CSV & JSON)
- 🔎 Search & Filter Candidates
- ⚡ Modern Responsive Dashboard
- 🐳 Docker Support

---

# 🖥️ Demo Workflow

```
Upload Job Description
          │
          ▼
Upload Multiple Resumes
          │
          ▼
Resume Parsing
          │
          ▼
Information Extraction
          │
          ▼
Semantic Similarity Analysis
          │
          ▼
Weighted Candidate Scoring
          │
          ▼
Candidate Ranking
          │
          ▼
Export CSV / JSON
```

---

# 🧠 AI Pipeline

The application performs the following steps:

1. Parse uploaded resumes
2. Extract candidate information
3. Generate embeddings using Sentence Transformers
4. Compare resumes with the Job Description
5. Calculate semantic similarity
6. Apply weighted scoring
7. Rank candidates
8. Generate downloadable reports

---

# 📊 Candidate Scoring

| Criteria | Weight |
|----------|--------|
| Skills | 50% |
| Experience | 20% |
| Education | 10% |
| Projects | 10% |
| Certifications | 10% |

Final Score = Weighted Score + Semantic Similarity

---

# 🛠 Tech Stack

## Frontend

- React
- Vite
- Tailwind CSS
- Axios

## Backend

- FastAPI
- Python

## AI / NLP

- Sentence Transformers
- all-MiniLM-L6-v2
- spaCy
- Regex-based Resume Parsing

## File Processing

- PyMuPDF
- pdfplumber
- python-docx

## Deployment

- Docker
- Docker Compose

---

# 📁 Project Structure

```
resume-screening-agent/

├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── parser.py
│   │   ├── extractor.py
│   │   ├── scorer.py
│   │   ├── models.py
│   │   ├── utils.py
│   │   └── __init__.py
│   ├── uploads/
│   ├── output/
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   ├── public/
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── sample_data/
│   ├── jd/
│   └── resumes/
│
├── docker-compose.yml
├── README.md
└── .gitignore
```

---

# 🚀 Installation

## Clone Repository

```bash
git clone https://github.com/your-username/resume-screening-agent.git

cd resume-screening-agent
```

---

## Backend

```bash
cd backend

python -m venv .venv

.venv\Scripts\activate

pip install -r requirements.txt

uvicorn app.main:app --reload
```

Backend URL

```
http://127.0.0.1:8000
```

---

## Frontend

```bash
cd frontend

npm install

npm run dev
```

Frontend URL

```
http://localhost:5173
```

---

# 📚 API Endpoints

| Method | Endpoint | Description |
|---------|----------|-------------|
| GET | / | Health Check |
| POST | /upload-jd | Upload Job Description |
| POST | /upload-resumes | Upload Multiple Resumes |
| POST | /analyze | Analyze Candidates |
| GET | /download/csv | Download CSV |
| GET | /download/json | Download JSON |

---

# 📂 Sample Output

After analysis, generated files:

```
backend/output/

ranked_candidates.csv

ranked_candidates.json
```

---

# 🐳 Docker

```bash
docker-compose up --build
```

---

# 📈 Future Improvements

- LLM-powered resume summarization
- Interview question generation
- Candidate chatbot
- Email notifications
- Authentication
- Database integration
- Recruiter dashboard
- Cloud deployment
- ATS compatibility
- Resume feedback suggestions

---

# 💡 Why This Project?

This project demonstrates practical applications of:

- Natural Language Processing (NLP)
- Semantic Search
- AI-based Resume Screening
- FastAPI Development
- React Frontend Development
- Explainable Candidate Ranking

It is designed to help recruiters reduce manual effort while improving the quality and consistency of resume screening.

---

# 👨‍💻 Author

**Sanjay Gowda C A**

AI & Machine Learning Enthusiast

GitHub: https://github.com/your-username

LinkedIn: https://linkedin.com/in/your-profile

---

# ⭐ If you found this project useful

Please consider giving the repository a ⭐ on GitHub.
